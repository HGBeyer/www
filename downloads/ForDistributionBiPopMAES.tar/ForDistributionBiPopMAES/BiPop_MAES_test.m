%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright by Hans-Georg Beyer (HGB)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% (mu/mu, lambda)-MA-ES with path and rank-mu update and 
%% weighted recombination and fast (f) efficient M-update
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% this code is for starting with experiments
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 40;                  % search space dimensionality
y_lower = -5*ones(10,1); % lower box bound (will not be checked in code)
y_upper = 5*ones(10,1);  % upper box bound (will not be checked in code)
sigma_start = 1
lambda_start =  12
goal_f_name = 'HappyCat'; stepsize_stop = 1e-6;
goal_f_name = 'Katsuuras'; stepsize_stop = 1e-8;
goal_f_name = 'Rosenbrock'; stepsize_stop = 1e-8;
goal_f_name = 'Rastrigin'; stepsize_stop = 1e-8;
sigma_stop = 1e-6
% stepsize_stop = 1e-10;
f_stop = 1e-10
total_f_budget = 1e6
opt = 'minimization'

[y_opt, f_dyn, sigma_dyn, f_eval_dyn, lambda_dyn] = ...
  BiPop_MAES( lambda_start, goal_f_name, y_lower, y_upper, sigma_start, ...
              stepsize_stop, f_stop, total_f_budget, opt );


semilogy(sigma_dyn)
semilogy(f_dyn)
semilogy(lambda_dyn, 'r')
plot(f_eval_dyn)
Rastrigin(y_opt)
HappyCat(y_opt)
Katsuuras(y_opt)
