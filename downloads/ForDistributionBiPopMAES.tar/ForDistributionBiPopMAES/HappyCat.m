%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright by Hans-Georg Beyer (HGB)
%% For teaching use only! It is not allowed to use 
%% this program without written permission by HGB 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a really hard function to be optimized
% see https://doi.org/10.1007/978-3-642-32937-1_37
% MA-ES as well as other well-known EAs have 
% problems to get close to the optimal solution
% Task: find a better algorithm!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f = HappyCat(y)
  n = length(y);
  r2 = sum(y .* y);
  f = abs(r2-n)^(0.25) + (0.5*r2 + sum(y))/n + 0.5;
end

