%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright by Hans-Georg Beyer (HGB)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% BiPop-MA-ES with path and rank-mu update and weighted recombination
%% using (fast) fMAES as search engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [y_opt, f_dyn, sigma_dyn, f_eval_dyn, lambda_dyn] = ...
  BiPop_MAES( lambda_start, goal_f_name, y_lower, y_upper, sigma_start, ...
              stepsize_stop, f_stop, total_f_budget, opt )

  if strcmp(opt, "maximization")
    maxi = 1;
  else
    maxi = 0;
  end

  IncPopSize = 2;
  dim = length(y_lower);
  y_init = y_lower + (y_upper-y_lower).*rand(dim, 1);
  sigma_init = sigma_start;
  g_stop = floor(total_f_budget/lambda_start);
  lambda = lambda_start;

  [y_opt_s, f_dyn_s, sigma_dyn_s] = ...
    fMAES( floor(lambda/2), lambda, goal_f_name, y_init, sigma_init, ...
           stepsize_stop, f_stop, g_stop, opt );

  f_opt = feval(goal_f_name, y_opt_s);
  y_opt = y_opt_s;
  g_end = length(f_dyn_s);
  f_dyn = f_dyn_s;
  sigma_dyn = sigma_dyn_s;
  f_eval_dyn = lambda*(1:g_end);
  f_eval_first_run = f_eval_dyn(end);
  lambda_dyn = lambda*ones(1,g_end);

  if (maxi) 
    if ( f_opt >= f_stop )
      return;
    end
  else
    if ( f_opt <= f_stop )
      return;
    end
  end 

  MArunIndex = 0;
  numberOfRunsOfSmallMA = 0;
  totalBudgetUsedForFarByAllSmallPop = 0;
  totalBudgetUsedForFarByAllLargePop = 0;

  while(1)
    MArunIndex = MArunIndex + 1;
    lambda = lambda_start * IncPopSize^(MArunIndex - numberOfRunsOfSmallMA);
    insigmafac = 1.0;
    runLargePop = 1;
    if (MArunIndex > 2) && ...
      (totalBudgetUsedForFarByAllSmallPop < totalBudgetUsedForFarByAllLargePop)
%     use small population
      insigmafac = 0.01^rand();
      lambda = floor( lambda_start ...
                      * (lambda/(IncPopSize * lambda_start))^(rand()^2));
      g_stop = floor( 0.5 * totalBudgetUsedForFarByAllLargePop / lambda );
      runLargePop = 0;
      numberOfRunsOfSmallMA = numberOfRunsOfSmallMA + 1;   
    else
      g_stop = floor(total_f_budget/lambda);
    end
  
    y_init = y_lower + (y_upper-y_lower).*rand(dim, 1);
    sigma_init = sigma_start * insigmafac;

    [y_opt_s, f_dyn_s, sigma_dyn_s] = ...
      fMAES( floor(lambda/2), lambda, goal_f_name, y_init, sigma_init, ...
            stepsize_stop, f_stop, g_stop, opt );

    g_end = length(f_dyn_s);
    f_dyn(end+1:end+g_end) = f_dyn_s;
    sigma_dyn(end+1:end+g_end) = sigma_dyn_s;
  
    f_eval_dyn(end+1:end+g_end) = f_eval_dyn(end) + lambda*(1:g_end);
    lambda_dyn(end+1:end+g_end) = lambda*ones(1,g_end);

    if (runLargePop == 1)
      totalBudgetUsedForFarByAllLargePop ...
       = totalBudgetUsedForFarByAllLargePop + lambda*g_end;
    else
      totalBudgetUsedForFarByAllSmallPop ...
       = totalBudgetUsedForFarByAllSmallPop + lambda*g_end;
    end

    f_opt_s = feval(goal_f_name, y_opt_s);
    if (maxi) 
      if ( f_opt_s > f_opt )
        f_opt = f_opt_s;
        y_opt = y_opt_s;
      end
      if ( f_opt >= f_stop )
        return;
      end
    else
      if ( f_opt_s < f_opt )
        f_opt = f_opt_s;
        y_opt = y_opt_s;
      end
      if ( f_opt <= f_stop )
        return;
      end
    end 

    if ( totalBudgetUsedForFarByAllSmallPop + f_eval_first_run ...
          + totalBudgetUsedForFarByAllLargePop >=  total_f_budget ) 
      return;
    end
  end % while
end
