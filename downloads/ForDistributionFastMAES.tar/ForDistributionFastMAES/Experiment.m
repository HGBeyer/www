%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright by Hans-Georg Beyer (HGB)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dynamics of fastMA-ES on Sphere, Cigar, Tablet, Elli, Rosenbrock, diffPowers
%% and HappyCat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 128;               % Dimensionality
y_init = ones(n, 1);   % Initialization
sigma_init = 1;        % Initialization
f_stop = 1e-20;        % Stopping if objective function smaller than f_stop
g_stop = 50000;        % Stopping if generation counter exceeds g_stop
stepsize_stop = 1e-12; % Stopping if parental step length smaller 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sphere
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fname = 'Sphere'
[y_opt_ma, f_dyn_ma, sigma_dyn_ma] = ...
  fMAES( floor((4+floor(3*log(n)))/2), 4+floor(3*log(n)), fname, y_init, ...
        sigma_init, stepsize_stop, f_stop, g_stop, 'minimization');

figure(1)
semilogy(f_dyn_ma, 'r')
hold on
semilogy(sigma_dyn_ma, 'b')
xlabel('g')
ylabel('f  and  sigma')
title(fname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cigar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fname = 'Cigar'
[y_opt_ma, f_dyn_ma, sigma_dyn_ma] = ...
  fMAES( floor((4+floor(3*log(n)))/2), 4+floor(3*log(n)), fname, y_init, ...
        sigma_init, stepsize_stop, f_stop, g_stop, 'minimization');

figure(2)
semilogy(f_dyn_ma, 'r')
hold on
semilogy(sigma_dyn_ma, 'b')
xlabel('g')
ylabel('f  and  sigma')
title(fname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tablet aka Discus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fname = 'Tablet'
[y_opt_ma, f_dyn_ma, sigma_dyn_ma] = ...
  fMAES( floor((4+floor(3*log(n)))/2), 4+floor(3*log(n)), fname, y_init, ...
        sigma_init, stepsize_stop, f_stop, g_stop, 'minimization');

figure(3)
semilogy(f_dyn_ma, 'r')
hold on
semilogy(sigma_dyn_ma, 'b')
xlabel('g')
ylabel('f  and  sigma')
title(fname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ellipsoid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fname = 'Elli'
[y_opt_ma, f_dyn_ma, sigma_dyn_ma] = ...
  fMAES( floor((4+floor(3*log(n)))/2), 4+floor(3*log(n)), fname, y_init, ...
        sigma_init, stepsize_stop, f_stop, g_stop, 'minimization');

figure(4)
semilogy(f_dyn_ma, 'r')
hold on
semilogy(sigma_dyn_ma, 'b')
xlabel('g')
ylabel('f  and  sigma')
title(fname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rosenbrock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fname = 'Rosenbrock'
[y_opt_ma, f_dyn_ma, sigma_dyn_ma] = ...
  fMAES( floor((4+floor(3*log(n)))/2), 4+floor(3*log(n)), fname, ...
        zeros(n,1), sigma_init, stepsize_stop, f_stop, g_stop, 'minimization');

figure(5)
semilogy(f_dyn_ma, 'r')
hold on
semilogy(sigma_dyn_ma, 'b')
xlabel('g')
ylabel('f  and  sigma')
title(fname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% different Powers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fname = 'diffPowers'
[y_opt_ma, f_dyn_ma, sigma_dyn_ma] = ...
  fMAES( floor((4+floor(3*log(n)))/2), 4+floor(3*log(n)), fname, y_init, ...
        sigma_init, stepsize_stop, f_stop, g_stop, 'minimization');

figure(6)
semilogy(f_dyn_ma, 'r')
hold on
semilogy(sigma_dyn_ma, 'b')
xlabel('g')
ylabel('f  and  sigma')
title(fname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% where all standard optimization algorithms do fail including MA-ES:
% HappyCat 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fname = 'HappyCat'
[y_opt_ma, f_dyn_ma, sigma_dyn_ma] = ...
  fMAES( floor((4+floor(3*log(n)))/2), 4+floor(3*log(n)), fname, y_init, ...
        sigma_init, stepsize_stop, f_stop, 50000, 'minimization');

figure(7)
semilogy(f_dyn_ma, 'r')
hold on
semilogy(sigma_dyn_ma, 'b')
xlabel('g')
ylabel('f  and  sigma')
title(fname)

