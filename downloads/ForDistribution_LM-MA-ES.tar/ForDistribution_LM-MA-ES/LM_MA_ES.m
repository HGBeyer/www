%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Limited Memory LM-MA-ES with gamma z-paths (stored in p_matrix), 
%% cumulative step size adaptation (CSA), and weighted recombination
%% 
%% Note, this implementation is not optimized for vector operations in Matlab.
%% For large search space dimensionalities n > 500, it is also recommended to 
%% code this in C, C++, or Fortran
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% I. Loshchilov, T. Glasmachers, and H.-G. Beyer
%% "Large Scale Black-Box Optimization by Limited-Memory Matrix Adaptation" 
%% IEEE Transactions on Evolutionary Computation, vol. 23, no. 2, pp. 353-358
%% DOI: 10.1109/TEVC.2018.2855049 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% n - search space dimensionality of y-vector in f(y) -> opt.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% returns:
%% y_opt - approximation of the optimizer
%% f_dyn - the dynamics of the parental f-values
%% sigma_dyn - dynamics of the mutation strength sigma
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% n -             search space dimensionality of y-vector in f(y) -> opt.
%% lambda -        offspring population size: lambda = 4 + floor(3*log(n))
%% mu -            parental population size: default size: lambda/2
%% gamma -         number of path vectors used: default size gamma = lambda
%% goal_f_name -   name of objective function f to be optimized
%% y_init -        initial y-vector (start vector)
%% sigma_init -    initial mutation stregth sigma
%% stepsize_stop - if parental change in search space is smaller then stop
%% f_stop -        stop if f gets smaller (minimize) or larger (maximization)
%% g_stop -        maximum number of generations until termination
%% opt -           "maximization" or "minimization"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [y_opt, f_dyn, sigma_dyn] = ...
  LM_MA_ES( mu, lambda, gamma, goal_f_name, y_init, sigma_init, ...
           stepsize_stop, f_stop, g_stop, opt )

  dim = length(y_init);
  wi_raw = log(lambda/2 + 0.5) - log((1:mu));
  wi = wi_raw/sum(wi_raw);
  mu_eff = 1/sum(wi .^2);
  c_s = 2*lambda/dim;
  sqrt_s = sqrt(c_s*(2-c_s)*mu_eff);
  cp = lambda/dim*4.^-(0:gamma-1);
  cd = 1.5.^-(0:gamma-1) / dim;
  sqrt_cp = sqrt(cp .* (2-cp) * mu_eff);
  Parent.y = y_init;
  sigma = sigma_init;
  s = ones(dim, 1);
  if strcmp(opt, "maximization")
    ordering = "descend";
    maxi = 1;
    f_bsf = -1e300;
  else
    ordering = "ascend";
    maxi = 0;
    f_bsf = 1e300;
  end
  f_dyn = [];
  sigma_dyn = [];
  g = 0;
  p_matrix = zeros(dim, gamma);
  while(1)
    clear OffspringPop;
    for l=1:lambda
      Offspring.z = randn(dim, 1);
      d = Offspring.z;
      for j = 1:min(g, gamma)
        d = (1-cd(j))*d + (cd(j)*(p_matrix(:, j)'*d)) * p_matrix(:, j);
      end
      Offspring.d = d;
      Offspring.f = feval(goal_f_name, Parent.y + sigma*Offspring.d);
      OffspringPop(l) = Offspring;
    end
    ranks = RankPop(OffspringPop, ordering);
    sum_z = zeros(dim, 1);
    sum_d = zeros(dim, 1);
    for m = 1:mu; 
      sum_z = sum_z + wi(m)*OffspringPop(ranks(m)).z;
      sum_d = sum_d + wi(m)*OffspringPop(ranks(m)).d;
    end
    Parent.z = sum_z;
    Parent.d = sum_d;
    Parent.y = Parent.y + sigma*Parent.d;
    s = (1-c_s)*s + sqrt_s*Parent.z;
    for i=1:gamma
      p_matrix(:, i) = (1-cp(i))*p_matrix(:, i) + sqrt_cp(i)*Parent.z;
    end
    sigma = sigma*exp(0.5*c_s*(norm(s)^2/dim - 1));
    g = g+1;
% Statistics:
    Parent.f = feval(goal_f_name, Parent.y);
    f_dyn(g) = Parent.f; 
    sigma_dyn(g) = sigma;
% Termination conditions:
    if ( maxi )
      if (Parent.f > f_bsf)
        f_bsf = Parent.f;
        y_opt = Parent.y;
      end
      if ( Parent.f > f_stop ...
        || g > g_stop ...
        || norm(sigma*Parent.d) < stepsize_stop ...
        || ( (g > 10) && abs(f_dyn(g)-f_dyn(g-10)) <= 100*eps(abs(f_dyn(g))) ))         break;
      end
    else
      if (Parent.f < f_bsf)
        f_bsf = Parent.f;
        y_opt = Parent.y;
      end
      if (Parent.f < f_stop ...
        || g > g_stop ...
        || norm(sigma*Parent.d) < stepsize_stop ...
        || ( (g > 10) && abs(f_dyn(g)-f_dyn(g-10)) <= 100*eps(abs(f_dyn(g))) )) 
        break;
      end
    end
  end
end
