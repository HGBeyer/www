%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright by Hans-Georg Beyer (HGB)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Test LM-MA-ES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% I. Loshchilov, T. Glasmachers and H.-G. Beyer
%% "Large Scale Black-Box Optimization by Limited-Memory Matrix Adaptation" 
%% IEEE Transactions on Evolutionary Computation, vol. 23, no. 2, pp. 353-358
%% DOI: 10.1109/TEVC.2018.2855049 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 128;
lambda = 4 + floor(3*log(n));
mu = floor(lambda/2);
sigma_init = 1;
stepsize_stop = 1e-10; 
f_stop = 1e-10; 
g_stop = 5000*n; 
opt = "minimization";

gamma = lambda;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

goal_f_name = "Sphere";

disp(goal_f_name);
y_init = ones(n, 1);
[y_opt_lm, f_dyn_lm, sigma_dyn_lm] = ...
  LM_MA_ES( mu, lambda, gamma, goal_f_name, y_init, sigma_init, ...
            stepsize_stop, f_stop, g_stop, opt );

figure(1);
semilogy(f_dyn_lm, "k"); % generation dynamics
semilogy(lambda*(1:length(f_dyn_lm)), f_dyn_lm, "k"); % function evaluations
xlabel('# fevals')
ylabel('f-values')
title(goal_f_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

goal_f_name = "Cigar";

disp(goal_f_name);
y_init = ones(n, 1);
[y_opt_lm, f_dyn_lm, sigma_dyn_lm] = ...
  LM_MA_ES( mu, lambda, gamma, goal_f_name, y_init, sigma_init, ...
            stepsize_stop, f_stop, g_stop, opt );

figure(2);
semilogy(f_dyn_lm, "k"); % generation dynamics
semilogy(lambda*(1:length(f_dyn_lm)), f_dyn_lm, "k"); % function evaluations
xlabel('# fevals')
ylabel('f-values')
title(goal_f_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

goal_f_name = "Tablet";

disp(goal_f_name);
y_init = ones(n, 1);
[y_opt_lm, f_dyn_lm, sigma_dyn_lm] = ...
  LM_MA_ES( mu, lambda, gamma, goal_f_name, y_init, sigma_init, ...
            stepsize_stop, f_stop, g_stop, opt );

figure(3);
semilogy(f_dyn_lm, "k"); % generation dynamics
semilogy(lambda*(1:length(f_dyn_lm)), f_dyn_lm, "k"); % function evaluations
xlabel('# fevals')
ylabel('f-values')
title(goal_f_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

goal_f_name = "Elli";

disp(goal_f_name);
y_init = ones(n, 1);
[y_opt_lm, f_dyn_lm, sigma_dyn_lm] = ...
  LM_MA_ES( mu, lambda, gamma, goal_f_name, y_init, sigma_init, ...
            stepsize_stop, f_stop, g_stop, opt );

figure(4);
semilogy(f_dyn_lm, "k"); % generation dynamics
semilogy(lambda*(1:length(f_dyn_lm)), f_dyn_lm, "k"); % function evaluations
xlabel('# fevals')
ylabel('f-values')
title(goal_f_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

goal_f_name = "diffPowers";

disp(goal_f_name);
y_init = ones(n, 1);
[y_opt_lm, f_dyn_lm, sigma_dyn_lm] = ...
  LM_MA_ES( mu, lambda, gamma, goal_f_name, y_init, sigma_init, ...
            stepsize_stop, f_stop, g_stop, opt );

figure(5);
semilogy(f_dyn_lm, "k"); % generation dynamics
semilogy(lambda*(1:length(f_dyn_lm)), f_dyn_lm, "k"); % function evaluations
xlabel('# fevals')
ylabel('f-values')
title(goal_f_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

goal_f_name = "Rosenbrock";

% Note: sometimes the LM-MA-ES converges to the local minimum

disp(goal_f_name);
y_init = ones(n, 1);
[y_opt_lm, f_dyn_lm, sigma_dyn_lm] = ...
  LM_MA_ES( mu, lambda, gamma, goal_f_name, y_init, sigma_init, ...
            stepsize_stop, f_stop, g_stop, opt );

figure(6);
semilogy(f_dyn_lm, "k"); % generation dynamics
semilogy(lambda*(1:length(f_dyn_lm)), f_dyn_lm, "k"); % function evaluations
xlabel('# fevals')
ylabel('f-values')
title(goal_f_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
